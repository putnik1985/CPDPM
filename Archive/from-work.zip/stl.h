
#ifndef STL_H
#define STL_H

#include <sstream>
#include <cmath>
#include <numeric>
#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include<stdexcept>

using namespace std;

#endif
