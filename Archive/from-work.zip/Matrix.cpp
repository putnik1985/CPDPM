#include <stdio.h>
#include <string.h>

#include "Read_Translat_Mesh.h"

int main(int argc, char *argv[]){

Create_FEM(cin); 

  /*
   char c;
   while ( (c = getchar()) !=EOF )
   putchar(c);            
   */
   
/*
   Matrix<double> m(4);
   for(int i=1;i<=4;++i)
   for(int j=1;j<=4;++j)
   m(i,j)=i+j;
   m.print();

   Matrix<double> m2 = m;
   m2.print();


   m2.set_dimension(8);
   m2.print();
*/


return 0;
}
